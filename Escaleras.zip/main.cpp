#include <iostream>
#include <vector>

using namespace std;

void resolverEscaleras(int n) {
    if (n < 0) {
        cout << "Error: El numero de escalones debe ser mayor o igual a 0." << endl;
        return;
    }

    vector<long long> dp(n + 1, 0);

    dp[0] = 1; 
    if (n >= 1) {
        dp[1] = 1; 
    }

    for (int i = 2; i <= n; ++i) {
        dp[i] = dp[i - 1] + dp[i - 2];
    }

    cout << "Formas posibles: " << dp[n] << endl;
    cout << "Tabla DP:" << endl;
    cout << "[";
    for (int i = 0; i <= n; ++i) {
        cout << dp[i] << (i < n ? ", " : "");
    }
    cout << "]" << endl;
}

int main() {
    int n;
    cout << "=== PROBLEMA 1: ESCALERAS ===" << endl;
    cout << "Ingrese el numero de escalones (N): ";
    if (!(cin >> n)) {
        cout << "Entrada invalida." << endl;
        return 1;
    }

    resolverEscaleras(n);
    return 0;
}
