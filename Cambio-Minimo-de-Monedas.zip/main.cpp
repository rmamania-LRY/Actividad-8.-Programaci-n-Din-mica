#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;
                
void resolverCambioMonedas(const vector<int>& monedas, int objetivo) {
    if (objetivo < 0) {
        cout << "Error: La cantidad objetivo no puede ser negativa." << endl;
        return;
    }

    const int INF = objetivo + 1;
    vector<int> dp(objetivo + 1, INF);

    vector<int> ultima_moneda(objetivo + 1, -1);

    dp[0] = 0;

    for (int i = 1; i <= objetivo; ++i) {
        for (int moneda : monedas) {
            if (moneda > 0 && i >= moneda && dp[i - moneda] + 1 < dp[i]) {
                dp[i] = dp[i - moneda] + 1;
                ultima_moneda[i] = moneda;
            }
        }
    }

    if (dp[objetivo] == INF) {
        cout << "No es posible formar la cantidad " << objetivo << " con las monedas dadas." << endl;
        return;
    }

    cout << "Cantidad minima de monedas: " << dp[objetivo] << endl;

    vector<int> combinacion;
    int actual = objetivo;
    while (actual > 0) {
        int m = ultima_moneda[actual];
        combinacion.push_back(m);
        actual -= m;
    }

    cout << "Combinacion: ";
    for (size_t i = 0; i < combinacion.size(); ++i) {
        cout << combinacion[i] << (i + 1 < combinacion.size() ? " + " : "");
    }
    cout << endl;

    cout << "Tabla DP:" << endl;
    cout << "[";
    for (int i = 0; i <= objetivo; ++i) {
        if (dp[i] == INF) cout << "INF";
        else cout << dp[i];
        cout << (i < objetivo ? "," : "");
    }
    cout << "]" << endl;
}

int main() {
    int num_monedas, objetivo;
    cout << "=== PROBLEMA 2: CAMBIO MINIMO DE MONEDAS ===" << endl;
    if (!(cin >> num_monedas) || num_monedas <= 0) {
        return 1;
    }

    vector<int> monedas(num_monedas);
    for (int i = 0; i < num_monedas; ++i) {
        cin >> monedas[i];
    }

    cout << "Ingrese la cantidad objetivo: ";
    if (!(cin >> objetivo)) {
        return 1;
    }

    resolverCambioMonedas(monedas, objetivo);
    return 0;
}
